import { CommonModule } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, ReactiveFormsModule } from '@angular/forms';

interface Empleado {
  matricula: string;
  nombre: string;
  correo: string;
  edad: number;
  horas: number;
}

@Component({
  selector: 'app-empleados',
  standalone: true,
  imports: [ReactiveFormsModule, CommonModule],
  templateUrl: './empleados.component.html',
  styles: [``]
})
export default class EmpleadosComponent implements OnInit {
  empleadoForm!: FormGroup;
  empleados: Empleado[] = [];

  constructor(private fb: FormBuilder) {}

  ngOnInit(): void {
    this.empleadoForm = this.fb.group({
      matricula: [''],
      nombre: [''],
      correo: [''],
      edad: [''],
      horas: ['']
    });
  }

  onSubmit(): void {
    const nuevoEmpleado: Empleado = this.empleadoForm.value;
    this.empleados.push(nuevoEmpleado);
    localStorage.setItem('empleados', JSON.stringify(this.empleados));
    this.empleadoForm.reset();
  }

  calcularPagoNormal(horas: number): number {
    const tarifaNormal = 70;
    const horasNormales = Math.min(horas, 40);
    return horasNormales * tarifaNormal;
  }

  calcularPagoExtra(horas: number): number {
    const tarifaExtra = 140;
    const horasExtras = Math.max(horas - 40, 0);
    return horasExtras * tarifaExtra;
  }

  calcularPagoTotal(horas: number): number {
    return this.calcularPagoNormal(horas) + this.calcularPagoExtra(horas);
  }

  modificar(matricula: string): void {
    const empleado = this.empleados.find(e => e.matricula === matricula);
    if (empleado) {
      this.empleadoForm.setValue(empleado);
      this.eliminar(matricula);
    }
  }

  eliminar(matricula: string): void {
    this.empleados = this.empleados.filter(e => e.matricula !== matricula);
    localStorage.setItem('empleados', JSON.stringify(this.empleados));
  }
}
